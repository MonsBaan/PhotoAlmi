//--------------------mysql----------------------
const mysql = require('mysql2');

const conn = mysql.createConnection({
    host: 'localhost',
    user: 'staleman',
    password: 'Almi_123',
    database: 'KalmihootWeb'
  });

  conn.connect((err) => 
  {
    if(err)
    {
      console.log(err);
      return;
    }
    console.log('Conexion establecida con mysql');
  });
 
  module.exports = conn;
