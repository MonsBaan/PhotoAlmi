//---------------------moongose------------------
const mongoose = require('mongoose');

mongoose.connect('mongodb://localhost/kalmihoott', {useNewUrlParser: true, useUnifiedTopology: true});
const conn = mongoose.connection;

if (!conn) 
{
    console.log('error de conexion con mongo!!!');    
}
else
{
    console.log('mongo bongo tongo!!');
}
module.exports = conn;
