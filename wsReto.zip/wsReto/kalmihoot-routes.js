// express 
const router = require('express').Router();

router.get('/', (req, res) =>
{
    res.json({
        status:"kalmihoot api funcionando!!",
        message:"kalmihoot activo en tu kokoro"
    });
});

const kalmihoot = require('./controlador/kalmihootController');

//------------------------------mongoDB---------------------------------
//****collection preguntas*****

//get questions
router.route('/preguntas').get(kalmihoot.all);

//new questions
router.route('/nuevas').post(kalmihoot.news);

//push in preguntas
router.route('/actualizar/:categoria').put(kalmihoot.upOne);

//get, delete or update contente by tipo and id 
router.route('/contenido/:id')
.delete(kalmihoot.deleteOne)
.get(kalmihoot.getOne)
.put(kalmihoot.updateOne);

//delete categoria
router.route('/pregunta/:id/:idPregunta').put(kalmihoot.pull);

//update quest
router.route('/actualizar/pregunta/:id/:idPregunta').put(kalmihoot.upQuest);

//update numAciertos
router.route('/numAciertos/:id/:idPregunta/:numAciertos').put(kalmihoot.upNum);

//get categorias
router.route('/categorias').get(kalmihoot.categoria);

//by category
router.route('/preguntas/:categoria').get(kalmihoot.getpregunta);

//****collection puntuacion*****

//get top10
router.route('/top10').get(kalmihoot.top);

//new score
router.route('/puntuacion/:id').put(kalmihoot.newScore);

//------------------------------------mysql---------------------------------

router.route('/trabajadores/:id')
.get(kalmihoot.findOne)
.delete(kalmihoot.deleteone)
.put(kalmihoot.updateOne);

router.route('/altas').post(kalmihoot.new);

router.route('/trabajadores').get(kalmihoot.findAll);

router.route('/puestos').get(kalmihoot.getStalls);

router.route('/trabajador/:dni/:contrasena').get(kalmihoot.One)

//export Routes
module.exports = router;