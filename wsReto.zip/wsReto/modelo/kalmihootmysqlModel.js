const mysql = require('../configuracion/conexionMysql');
//mysqlSchema
const trabajadoresSchema = function(trabajador) 
{
    this.id_trabjador = trabajador.id_trabajador;
    this.nombre = trabajador.nombre;
    this.apellido1 = trabajador.apellido1;
    this.apellido2 = trabajador.apellido2;
    this.dni = trabajador.dni;
    this.direccion = trabajador.direccion;
    this.telefono = trabajador.telefono;
    this.contrasena = trabajador.contrasena;
    this.imagen = trabajador.imagen;
    this.puesto = trabajador.puesto;
};
//create
trabajadoresSchema.create = (newTrabajador, result) => 
{

    mysql.query("call crearNuevoTrabajador(?, ?, ?, ?, ?, ?, ?)", [newTrabajador.dni,
            newTrabajador.nombre,
            newTrabajador.apellido1,
            newTrabajador.apellido2,
            newTrabajador.direccion,
            newTrabajador.telefono,
            newTrabajador.puesto
        ],
        (err, res) => 
        {
            if (err) 
            {
                console.log("error: ", err);
                result(err, null);
                return;
            }
            console.log("Trabajador creado: ", { id: res.insertId, ...newTrabajador });
            result(null, { id: res.insertId, ...newTrabajador });
        });
};
//find worker by id
trabajadoresSchema.findById = (trabajadorId, result) => 
{
    mysql.query(`SELECT * FROM trabajadores WHERE id_trabajador=${trabajadorId}`, (err, res) => 
    {
        if (err) 
        {
            console.log("error: ", err);
            result(err, null);
            return;
        }
        if (res.length) 
        {
            console.log("trabajador encontrado: ", res[0]);
            result(null, res[0]);
            return;
        }
        // no encontrado
        result({ kind: "not_found" }, null);
    });
};
//find a worker in login
trabajadoresSchema.getOne = (dni, contrasena, result) =>
{
  mysql.query(`SELECT * FROM trabajadores INNER JOIN puestos ON trabajadores.puesto = puestos.id_puesto WHERE dni = "${dni}" AND contrasena = "${contrasena}"`, (err,res) =>
  {
    if (err) 
    {
        console.log("error: ", err);
        result(err, null);
        return;
    }
    if (res.length) 
    {
        console.log("trabajador: ", res[0]);
        result(null, res[0]);
        return;
    }
    // no encontrado
    result({ kind: "not_found" }, null);
});
};
//find all
trabajadoresSchema.getAll = result => 
{
    mysql.query("SELECT * FROM trabajadores INNER JOIN puestos ON trabajadores.puesto = puestos.id_puesto ", (err, res) => {
        if (err) 
        {
            console.log("error: ", err);
            result(null, err);
            return;
        }
        console.log("trabajadores: ", res);
        result(null, res);
    });
};
trabajadoresSchema.getStallsman = result =>
{
    mysql.query("SELECT * FROM puestos", (err, res) =>
    {
        if (err) 
        {
            console.log("error: ", err);
            result(null, err);
            return;
        }
        console.log("puestos: ", res);
        result(null, res);
    });
};
trabajadoresSchema.dropOne = (trabajadorId, result) =>
{
    mysql.query(`DELETE FROM trabajadores WHERE id_trabajador=${trabajadorId}`, (err, res) =>
    {
        if (err) 
        {
            console.log("error: ", err);
            result(null, err);
            return;
        }
      
        if (res.affectedRows == 0) 
        {
            
            result({ kind: "not_found" }, null);
            return;
        }
        console.log("has matado al trabajador con id: ", trabajadorId);
        result(null, res);
    });
};
trabajadoresSchema.updateByid = (trabajadorId, trabajador, result) =>
{
    mysql.query("UPDATE trabajadores SET nombre=?, apellido1=?, apellido2=?, dni=?, direccion=?, telefono=?, contrasena=?, puesto=?, imagen=? WHERE id_trabajador=?",[trabajador.nombre, 
        trabajador.apellido1, 
        trabajador.apellido2,
        trabajador.dni,
        trabajador.direccion,
        trabajador.telefono,
        trabajador.contrasena,
        trabajador.puesto,
        trabajador.imagen,
        trabajadorId,
        ], 
        (err, res) =>
        {
            if (err) 
            {
                console.log("error: ", err);
                result(null, err);
                return;
            }
            if (res.affectedRows == 0) 
            {
                
                result({ kind: "not_found" }, null);
                return;
            }
            console.log("Trabajador actualizado: ", { id: trabajadorId, ...trabajador });
            result(null, { id: trabajadorId, ...trabajador });
        });
};

module.exports = trabajadoresSchema;