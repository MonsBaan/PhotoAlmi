//model
const moongose = require('mongoose');
//schema of collection preguntas
var preguntasSchema = new moongose.Schema(
    {
        categoria:
        {
            require: true,
            type: String
        },
        preguntas:
            [
                {
                    
                    imagen:
                    {
                        require: true,
                        type: String
                    },
                    pregunta:
                    {
                        require: true,
                        type: String
                    },

                    respuestas:
                        [
                            {
                                respuesta: String,
                                correcta: Boolean
                            }
                        ],
                    correccion: String,
                    numAciertos: Number
                }
            ]
    },
    {
        collection: 'preguntas'
    },
    {
        versionKey: false
    },
);
var puntuacionSchema = new moongose.Schema(
    {
        nick:
        {
            require: true,
            type: String
        },
        puntuacion:
        {
            resquire: true,
            type: Number
        }
    },
    {
        collection: 'puntuacion'
    },
    {
        versionKey: false
    },
    
);

//finds puntuaciones
let puntuacion = module.exports = moongose.model('puntuacion', puntuacionSchema);

//finds preguntas 
let preguntas = module.exports = moongose.model('preguntas', preguntasSchema);
//-------------------PREGUNTAS-------------------------
module.exports.get = (callback, limit) => 
{
    console.log("todo")
    preguntas.find(callback).limit(limit);
}
module.exports.getOne = (callback, id) =>
{
    console.log("get one")
    preguntas.findOne({'_id':id}, callback);
}
module.exports.deleteByid = (callback, id) =>
{
    console.log("delete category")
    preguntas.deleteOne({'_id':id}, callback);
}
module.exports.updateByid = (callback, id, body) =>
{
    console.log("update one")
    preguntas.updateOne({'_id':id}, body, callback);
}
module.exports.getCategory = (callback) => 
{
    console.log("categorias")
    preguntas.distinct('categoria', callback);
}
module.exports.byCat = (callback, category) =>
{
    console.log("por categoria")
    preguntas.findOne({'categoria':category}, callback);
}
module.exports.pushOne = (callback, pregunta, category) =>
{
    console.log("push question")
    preguntas.updateOne({'categoria':category},
    {$push:{'preguntas':pregunta}},callback);
}
module.exports.pullOne = (callback, id, idPregunta) =>
{
    console.log("pull question")
    preguntas.updateOne({"_id":id}, {$pull:{"preguntas":{"_id":idPregunta}}},callback);
}
//update numAciertos
module.exports.updateNumA = (callback, id, idPregunta, numAciertos) =>
{
    console.log("update numAciertos")
    preguntas.updateOne({'_id':id, 'preguntas._id':idPregunta},{$set:{'preguntas.$.numAciertos':numAciertos}}, callback);
}
//update one questions of arr preguntas
module.exports.updateQuest = (callback, id, idPregunta, body) =>
{
    console.log("update question")
    preguntas.updateOne({'_id':id, 'preguntas._id':idPregunta},{$set:{'preguntas.$':body}}, callback);
}
//--------------------PUNTUACION-----------------------
module.exports.top10 = (callback) =>
{
    console.log("top10")
    puntuacion.aggregate([{$sort:{'puntuacion':-1}}, {$limit:10}], callback);
}
module.exports.updateTop = (callback, id, body) =>
{
    console.log("actualizar top")
    puntuacion.updateOne({'_id':id}, body, callback);
}






