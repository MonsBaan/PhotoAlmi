//kalmihoot
const express =  require('express');
const mongodb = require('./configuracion/conexionMongodb');
//express
let app  = express();

let apiRoutes = require('./kalmihoot-routes');

//headers express
app.use((req, res, next) => 
{
    res.header('Access-Control-Allow-Origin', '*');
    res.header('Access-Control-Allow-Headers', 'Authorization, X-API-KEY, Origin, X-Requested-With, Content-Type, Accept, Access-Control-Allow-Request-Method');
    res.header('Access-Control-Allow-Methods', 'GET, POST, OPTIONS, PUT, DELETE');
    res.header('Allow', 'GET, POST, OPTIONS, PUT, DELETE');
    next();
});
app.use(express.urlencoded(
    {
        extended:true
    }
));
app.use(express.json());

  //port
  var port = process.env.PORT || 8080;

  //send message for default url
  app.get('/', (req,res) => res.send('Kalmihoot esta activo!!'));
  
  //launch app to listen to specified port
  app.listen(port, () =>
  {
      console.log('sr Kalmihoot activo en el puerto:  ' + port);
  });
//use api routes in app
app.use('/kalmihootApi', apiRoutes);


