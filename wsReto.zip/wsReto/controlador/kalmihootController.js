//controller
const preguntas = require('../modelo/kalmihootModel');

//----------------------PREGUNTAS--------------------------
//get all
exports.all = (req, res) =>
{
    preguntas.get((err, preguntas) =>
    {
        if(err)
        {
            console.log(err);
            res.json({
                status:"error",
                message:err
            });
        }
        else
        {
            res.json({
                status:"kalmihoot en camino",
                message:"las preguntas se enviaron correctamente",
                data:preguntas
            });
        }
    });
};
//get one
exports.getOne = (req, res) =>
{
    let id = req.params.id;
    preguntas.getOne((err, pregunta) =>
    {
        if(err)
        {
            console.log(err);
            res.json({
                status:"error",
                message:err
            });
        }
        else
        {
            res.json({
                status:"kalmihoot en camino",
                message:"pregunta enviada correctamente",
                data:pregunta
            });
        }
    }, id);
};
//push one
exports.upOne = (req, res) =>
{
    let categoria = req.params.categoria;
    let body = req.body;
    console.log(body);
    preguntas.pushOne((err, pregunta) =>
    {
        if(err)
        {
            console.log(err);
            res.json({
                status:"error",
                message:err
            });
        }
        else
        {
            res.json({
                status:"kalmihoot en camino",
                message:"pregunta actualizada correctamente",
                data:pregunta
            });
        }   
    }, body, categoria);
}
//update numAciertos
exports.upNum = (req, res) =>
{
    let id = req.params.id;
    let idPregunta = req.params.idPregunta;
    let numAciertos = req.params.numAciertos;
    preguntas.updateNumA((err, pregunta) =>
    {
        if(err)
        {
            console.log(err);
            res.json({
                status:"error",
                message:err
            });
        }
        else
        {
            res.json({
                status:"kalmihoot en camino",
                message:"numero de aciertos actualizado",
                data:pregunta
            });
        }   
    }, id, idPregunta, numAciertos);
}
//delete one
exports.deleteOne = (req,res) =>
{
    let id = req.params.id;
    preguntas.deleteByid((err, pregunta) =>
    {
        if(err)
        {
            console.log(err);
            res.json({
                status:"error",
                message:err
            });
        }
        else
        {
            res.json({
                status:"kalmihoot en camino",
                message:"pregunta borrada correctamente",
                data:pregunta
            });
        }
    }, id);
}
//update quest
exports.upQuest = (req, res) =>
{
    let id = req.params.id;
    let idPregunta = req.params.idPregunta;
    let body = req.body;
    preguntas.updateQuest((err,pregunta) =>
    {

        if(err)
        {
            console.log(err);
            res.json({
                status: "error",
                message: err
            });
        } 
        else
        {
            res.json({
                status:"kalmihoot en camino",
                message:"pregunta actualizada correctamente",
                data:pregunta
            });
        }
    }, id, idPregunta, body);
}
//update category
exports.updateOne = (req, res) =>
{
    let id = req.params.id;
    let body = req.body;
    preguntas.updateByid((err, pregunta) =>
    {
        if(err)
        {
            console.log(err);
            res.json({
                status: "error",
                message: err
            });
        } 
        else
        {
            res.json({
                status:"kalmihoot en camino",
                message:"categoria actualizada correctamente",
                data:pregunta
            });
        }
    }, id, body);
}
//get by category
exports.getpregunta = (req, res) =>
{
    let categoria = req.params.categoria;
    preguntas.byCat((err, preguntas) =>
    {
        
        if(err)
        {
            console.log(err);
            res.json({
                status:"error",
                message:err
            });
        }
        else
        {
            res.json({
                status:"kalmihoot en camino",
                message:"las preguntas se enviaron correctamente",
                data:preguntas
            });
        }
    }, categoria);
};
//get categorias
exports.categoria = (req, res) =>
{
    preguntas.getCategory((err, categorias) =>
    {
        if(err)
        {
            console.log(err);
            res.json({
                status:"error",
                message:err
            });
        }
        else
        {
            res.json({
                status:"kalmihoot en camino",
                message:"las catgorias cargadas correctamente",
                data:categorias
            });
        }
    });
}

//post new
exports.news = (req, res) =>
{
    let pregunta = new preguntas();
    pregunta.categoria = req.body.categoria;
    pregunta.preguntas = req.body.preguntas;
    pregunta.save((err) =>
    {
        if (err) 
        {
            console.log(err);    
        }
        else
        {
            console.log(pregunta);
            res.json({
                message:"nueva pregunta creada!!",
                data:pregunta
            });
        }
    });
};

//delete question
exports.pull = (req, res) =>
{
    let id = req.params.id;
    let idPregunta = req.params.idPregunta;
    preguntas.pullOne((err, preguntas) =>
    {
        if (err) 
        {
            console.log(err);    
        }
        else
        {
            console.log(preguntas);
            res.json({
                message:"nueva borrada!!",
                data:preguntas
            });
        }
    },id, idPregunta);
}
//----------------------PUNTUACION--------------------------
//get top
exports.top = (req, res) =>
{
    preguntas.top10((err, puntuacion) =>
    {
        if(err)
        {
            console.log(err);
            res.json({
                status:"error",
                message:err
            });
        }
        else
        {
            res.json({
                status:"kalmihoot en camino",
                message:"top10",
                data:puntuacion
            });
        }
    });
};

//new score
exports.newScore = (req, res) =>
{
    let id = req.params.id;
    let body = req.body;
    preguntas.updateTop((err, puntuacion) =>
    {
        if(err)
        {
            console.log(err);
            res.json({
                status: "error",
                message: err
            });
        } 
        else
        {
            res.json({
                status:"kalmihoot en camino",
                message:"nuevo record",
                data: puntuacion
            });
        }
    }, id, body);
};


//--------------------------------mysql-----------------------------------
const trabajadores = require('../modelo/kalmihootmysqlModel');
//create
exports.new = (req, res) =>
{
    //validate request
    if(!req.body)
    {
        res.status(400).send({
            message:"El contenido no puede quedar vacio!"
        });
    }
    
    //create a worker
    let trabajador = new trabajadores({
        nombre:req.body.nombre,
        apellido1:req.body.apellido1,
        apellido2: req.body.apellido2,
        dni: req.body.dni,
        direccion: req.body.direccion,
        telefono :req.body.telefono,
        contrasena: req.body.contrasena,
        puesto: req.body.puesto
    });
        
    //save
    trabajadores.create(trabajador, (err, data) =>
    {
        if(err)
        {
            res.status(500).send({
                message:
                err.message || "error al crear el trabajador"
            });
        }
        else
        {
            res.json({
                status:"kalmihoot en camino",
                message:"nuevo trabajador!!",
                data: data
              });
        }
    });
};
//find a worker
exports.findOne = (req, res) =>
{
    let id = req.params.id;
    trabajadores.findById(id, (err, data) =>
    {
        if (err) 
        {
            if (err.kind === "not_found") 
            {
              res.status(404).send({
                message: `nigun trabajdor encontrado con la id:  ${id}.`
              });
            } 
            else 
            {
              res.status(500).send({
                message: "Error sacando datos con id: " + id
              });
            }
          } 
          else 
          {
              res.json({
                  status:"kalmihoot en camino",
                  message:"trabajador",
                  data: data
                });
          }
    });
};
//find all workers
exports.findAll = (req, res) =>
{
    trabajadores.getAll((err, data) =>
    {
        if(err)
        {
            res.status(500).send({
                message:
                err.message || "error al crear el trabajador"
            });
        }
        else
        {
            res.json({
                status:"kalmihoot en camino",
                message:"toma trabajadores ibai, para ti , para mi, para toda la familia!!",
                data: data
              });
        }
    });
};

exports.One = (req, res) =>
{
    let dni = req.params.dni;
    let contrasena = req.params.contrasena;
    trabajadores.getOne(dni, contrasena, (err, data) =>
    {
        if(err)
        {
            res.status(500).send({
                message:
                err.message || "error al crear el trabajador"
            });
        }
        else
        {
            res.json({
                status:"kalmihoot en camino",
                message:"toma trabajador que ha iniciado sesion ibai pim pam ...!!",
                data: data
              });
        }
    });
};
exports.getStalls = (req, res) =>
{
    trabajadores.getStallsman((err, data) =>
    {
        if(err)
        {
            res.status(500).send({
                message:
                err.message || "error al crear el trabajador"
            });
        }
        else
        {
            res.json({
                status:"kalmihoot en camino",
                message:"toma puestos pim pam ...!!",
                data: data
              });
        }
    });
};
exports.deleteone = (req, res) =>
{
    let id = req.params.id;
    trabajadores.dropOne(id,(err, data) =>
    {
        if(err)
        {
            if (err.kind === "not_found") 
            {
                res.status(404).send({
                  message: `No encontrado trabajador con id: ${id}.`
                });
            } 
            else 
            {
                res.status(500).send({
                  message: `No se ha podido borrar el trabajador con id: ${id}.`
                });
            }
        }
        else
        {
            res.json({
                status:"kalmihoot en camino",
                message:"lo has matado!!! t.t",
                data: data
              });
        }
    });
};
//update
exports.updateOne = (req, res) =>
{
    //validate request
    if(!req.body)
    {
        res.status(400).send({
            message:"El contenido no puede quedar vacio!"
        });
    }
    
    //worker
    let trabajador = new trabajadores(req.body);
    //id
    let id = req.params.id;   
    //save
    trabajadores.updateByid(id, trabajador, (err, data) =>
    {
        if(err)
        {
            if (err.kind === "not_found") 
            {
                res.status(404).send({
                  message: `No encontrado trabajador con id: ${id}.`
                });
            } 
            else 
            {
                res.status(500).send({
                  message: `No se ha podido actualizar el trabajador con id: ${id}.`
                });
            }
        }
        else
        {
            res.json({
                status:"kalmihoot en camino",
                message:"trabajador actualizado!!",
                data: data
              });
        }
    });
};

