﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Menu
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Menu))
        Me.lblNick = New System.Windows.Forms.Label()
        Me.btnJugar = New System.Windows.Forms.Button()
        Me.btnCerrar = New System.Windows.Forms.Button()
        Me.comboCat = New System.Windows.Forms.ComboBox()
        Me.comboNivel = New System.Windows.Forms.ComboBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.lblCategoria = New System.Windows.Forms.Label()
        Me.lblDificultad = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.lblTiempo = New System.Windows.Forms.Label()
        Me.lblVidas = New System.Windows.Forms.Label()
        Me.lblPreguntas = New System.Windows.Forms.Label()
        Me.lblPuntos = New System.Windows.Forms.Label()
        Me.SuspendLayout()
        '
        'lblNick
        '
        Me.lblNick.BackColor = System.Drawing.Color.FromArgb(CType(CType(54, Byte), Integer), CType(CType(66, Byte), Integer), CType(CType(120, Byte), Integer))
        Me.lblNick.Font = New System.Drawing.Font("Centaur", 30.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point)
        Me.lblNick.ForeColor = System.Drawing.Color.White
        Me.lblNick.Location = New System.Drawing.Point(0, 0)
        Me.lblNick.Name = "lblNick"
        Me.lblNick.Size = New System.Drawing.Size(257, 85)
        Me.lblNick.TabIndex = 0
        Me.lblNick.Text = "Nick"
        Me.lblNick.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'btnJugar
        '
        Me.btnJugar.BackColor = System.Drawing.Color.FromArgb(CType(CType(54, Byte), Integer), CType(CType(66, Byte), Integer), CType(CType(120, Byte), Integer))
        Me.btnJugar.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.btnJugar.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnJugar.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(CType(CType(54, Byte), Integer), CType(CType(66, Byte), Integer), CType(CType(120, Byte), Integer))
        Me.btnJugar.FlatAppearance.BorderSize = 0
        Me.btnJugar.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnJugar.Font = New System.Drawing.Font("Centaur", 24.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.btnJugar.ForeColor = System.Drawing.Color.White
        Me.btnJugar.Location = New System.Drawing.Point(-1, 387)
        Me.btnJugar.Name = "btnJugar"
        Me.btnJugar.Size = New System.Drawing.Size(258, 63)
        Me.btnJugar.TabIndex = 2
        Me.btnJugar.Text = "JUGAR"
        Me.btnJugar.UseVisualStyleBackColor = False
        '
        'btnCerrar
        '
        Me.btnCerrar.BackColor = System.Drawing.Color.FromArgb(CType(CType(54, Byte), Integer), CType(CType(66, Byte), Integer), CType(CType(120, Byte), Integer))
        Me.btnCerrar.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.btnCerrar.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnCerrar.FlatAppearance.BorderSize = 0
        Me.btnCerrar.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnCerrar.Font = New System.Drawing.Font("Centaur", 24.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.btnCerrar.ForeColor = System.Drawing.Color.White
        Me.btnCerrar.Location = New System.Drawing.Point(-1, 97)
        Me.btnCerrar.Name = "btnCerrar"
        Me.btnCerrar.Size = New System.Drawing.Size(259, 50)
        Me.btnCerrar.TabIndex = 4
        Me.btnCerrar.Text = "Cerrar Sesión"
        Me.btnCerrar.UseVisualStyleBackColor = False
        '
        'comboCat
        '
        Me.comboCat.BackColor = System.Drawing.Color.FromArgb(CType(CType(54, Byte), Integer), CType(CType(66, Byte), Integer), CType(CType(120, Byte), Integer))
        Me.comboCat.Cursor = System.Windows.Forms.Cursors.Hand
        Me.comboCat.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.comboCat.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.comboCat.Font = New System.Drawing.Font("Centaur", 20.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.comboCat.ForeColor = System.Drawing.Color.White
        Me.comboCat.FormattingEnabled = True
        Me.comboCat.Items.AddRange(New Object() {"Algo"})
        Me.comboCat.Location = New System.Drawing.Point(12, 162)
        Me.comboCat.Name = "comboCat"
        Me.comboCat.Size = New System.Drawing.Size(233, 39)
        Me.comboCat.TabIndex = 5
        '
        'comboNivel
        '
        Me.comboNivel.BackColor = System.Drawing.Color.FromArgb(CType(CType(54, Byte), Integer), CType(CType(66, Byte), Integer), CType(CType(120, Byte), Integer))
        Me.comboNivel.Cursor = System.Windows.Forms.Cursors.Hand
        Me.comboNivel.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.comboNivel.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.comboNivel.Font = New System.Drawing.Font("Centaur", 20.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.comboNivel.ForeColor = System.Drawing.Color.White
        Me.comboNivel.FormattingEnabled = True
        Me.comboNivel.Items.AddRange(New Object() {"Facil", "Media", "Difícil"})
        Me.comboNivel.Location = New System.Drawing.Point(12, 207)
        Me.comboNivel.Name = "comboNivel"
        Me.comboNivel.Size = New System.Drawing.Size(233, 39)
        Me.comboNivel.TabIndex = 6
        '
        'Label2
        '
        Me.Label2.BackColor = System.Drawing.Color.FromArgb(CType(CType(43, Byte), Integer), CType(CType(117, Byte), Integer), CType(CType(174, Byte), Integer))
        Me.Label2.Location = New System.Drawing.Point(-1, 256)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(259, 112)
        Me.Label2.TabIndex = 7
        '
        'lblCategoria
        '
        Me.lblCategoria.BackColor = System.Drawing.Color.FromArgb(CType(CType(54, Byte), Integer), CType(CType(66, Byte), Integer), CType(CType(120, Byte), Integer))
        Me.lblCategoria.Font = New System.Drawing.Font("Centaur", 18.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.lblCategoria.ForeColor = System.Drawing.Color.White
        Me.lblCategoria.Location = New System.Drawing.Point(30, 168)
        Me.lblCategoria.Name = "lblCategoria"
        Me.lblCategoria.Size = New System.Drawing.Size(190, 27)
        Me.lblCategoria.TabIndex = 8
        Me.lblCategoria.Text = "Categoría"
        Me.lblCategoria.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lblDificultad
        '
        Me.lblDificultad.BackColor = System.Drawing.Color.FromArgb(CType(CType(54, Byte), Integer), CType(CType(66, Byte), Integer), CType(CType(120, Byte), Integer))
        Me.lblDificultad.Font = New System.Drawing.Font("Centaur", 18.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.lblDificultad.ForeColor = System.Drawing.Color.White
        Me.lblDificultad.Location = New System.Drawing.Point(30, 213)
        Me.lblDificultad.Name = "lblDificultad"
        Me.lblDificultad.Size = New System.Drawing.Size(190, 27)
        Me.lblDificultad.TabIndex = 9
        Me.lblDificultad.Text = "Dificultad"
        Me.lblDificultad.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.BackColor = System.Drawing.Color.FromArgb(CType(CType(43, Byte), Integer), CType(CType(117, Byte), Integer), CType(CType(174, Byte), Integer))
        Me.Label1.Location = New System.Drawing.Point(30, 266)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(50, 15)
        Me.Label1.TabIndex = 10
        Me.Label1.Text = "Tiempo:"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.BackColor = System.Drawing.Color.FromArgb(CType(CType(43, Byte), Integer), CType(CType(117, Byte), Integer), CType(CType(174, Byte), Integer))
        Me.Label3.Location = New System.Drawing.Point(30, 293)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(38, 15)
        Me.Label3.TabIndex = 11
        Me.Label3.Text = "Vidas:"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.BackColor = System.Drawing.Color.FromArgb(CType(CType(43, Byte), Integer), CType(CType(117, Byte), Integer), CType(CType(174, Byte), Integer))
        Me.Label4.Location = New System.Drawing.Point(30, 318)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(63, 15)
        Me.Label4.TabIndex = 12
        Me.Label4.Text = "Preguntas:"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.BackColor = System.Drawing.Color.FromArgb(CType(CType(43, Byte), Integer), CType(CType(117, Byte), Integer), CType(CType(174, Byte), Integer))
        Me.Label5.Location = New System.Drawing.Point(30, 344)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(47, 15)
        Me.Label5.TabIndex = 13
        Me.Label5.Text = "Puntos:"
        '
        'lblTiempo
        '
        Me.lblTiempo.AutoSize = True
        Me.lblTiempo.BackColor = System.Drawing.Color.FromArgb(CType(CType(43, Byte), Integer), CType(CType(117, Byte), Integer), CType(CType(174, Byte), Integer))
        Me.lblTiempo.Location = New System.Drawing.Point(118, 266)
        Me.lblTiempo.Name = "lblTiempo"
        Me.lblTiempo.Size = New System.Drawing.Size(17, 15)
        Me.lblTiempo.TabIndex = 14
        Me.lblTiempo.Text = "??"
        '
        'lblVidas
        '
        Me.lblVidas.AutoSize = True
        Me.lblVidas.BackColor = System.Drawing.Color.FromArgb(CType(CType(43, Byte), Integer), CType(CType(117, Byte), Integer), CType(CType(174, Byte), Integer))
        Me.lblVidas.Location = New System.Drawing.Point(118, 293)
        Me.lblVidas.Name = "lblVidas"
        Me.lblVidas.Size = New System.Drawing.Size(17, 15)
        Me.lblVidas.TabIndex = 15
        Me.lblVidas.Text = "??"
        '
        'lblPreguntas
        '
        Me.lblPreguntas.AutoSize = True
        Me.lblPreguntas.BackColor = System.Drawing.Color.FromArgb(CType(CType(43, Byte), Integer), CType(CType(117, Byte), Integer), CType(CType(174, Byte), Integer))
        Me.lblPreguntas.Location = New System.Drawing.Point(118, 318)
        Me.lblPreguntas.Name = "lblPreguntas"
        Me.lblPreguntas.Size = New System.Drawing.Size(17, 15)
        Me.lblPreguntas.TabIndex = 16
        Me.lblPreguntas.Text = "??"
        '
        'lblPuntos
        '
        Me.lblPuntos.AutoSize = True
        Me.lblPuntos.BackColor = System.Drawing.Color.FromArgb(CType(CType(43, Byte), Integer), CType(CType(117, Byte), Integer), CType(CType(174, Byte), Integer))
        Me.lblPuntos.Location = New System.Drawing.Point(118, 344)
        Me.lblPuntos.Name = "lblPuntos"
        Me.lblPuntos.Size = New System.Drawing.Size(18, 15)
        Me.lblPuntos.TabIndex = 17
        Me.lblPuntos.Text = "x?"
        '
        'Menu
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(7.0!, 15.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.FromArgb(CType(CType(6, Byte), Integer), CType(CType(170, Byte), Integer), CType(CType(219, Byte), Integer))
        Me.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.ClientSize = New System.Drawing.Size(257, 450)
        Me.ControlBox = False
        Me.Controls.Add(Me.lblPuntos)
        Me.Controls.Add(Me.lblPreguntas)
        Me.Controls.Add(Me.lblVidas)
        Me.Controls.Add(Me.lblTiempo)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.lblDificultad)
        Me.Controls.Add(Me.lblCategoria)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.comboNivel)
        Me.Controls.Add(Me.comboCat)
        Me.Controls.Add(Me.btnCerrar)
        Me.Controls.Add(Me.btnJugar)
        Me.Controls.Add(Me.lblNick)
        Me.DoubleBuffered = True
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.Name = "Menu"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Menu"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents lblNick As Label
    Friend WithEvents btnJugar As Button
    Friend WithEvents btnCerrar As Button
    Private WithEvents comboCat As ComboBox
    Friend WithEvents Label2 As Label
    Public WithEvents comboNivel As ComboBox
    Friend WithEvents lblCategoria As Label
    Friend WithEvents lblDificultad As Label
    Friend WithEvents Label1 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents Label4 As Label
    Friend WithEvents Label5 As Label
    Friend WithEvents lblTiempo As Label
    Friend WithEvents lblVidas As Label
    Friend WithEvents lblPreguntas As Label
    Friend WithEvents lblPuntos As Label
End Class
