﻿Imports Newtonsoft.Json
Imports WMPLib

Public Class Top
    Public menu As Menu
    Public puntos As Integer
    Public ganar As Boolean = False
    Private fondo As WindowsMediaPlayer = New WindowsMediaPlayer

    Private Sub Top_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        lblPuntuacion.Text = "Puntuación: " & puntos
        If Not ganar Then
            lblArriba.Text = "DERROTA"
            Me.BackColor = Color.LightPink
            lblTop.BackColor = Color.OrangeRed
            lblArriba.BackColor = Color.DarkRed
            lblPuntuacion.BackColor = Color.DarkRed
            playDerrota()
        Else
            playVictoria()
        End If
        If menu.almi Then
            almificar()
        End If
        cargarTop()
    End Sub
    Public Sub playDerrota()
        Dim songLocation = Application.StartupPath & "\derrota.mp3"
        fondo.URL = songLocation
        fondo.settings.setMode("Loop", True)
        fondo.controls.play()
    End Sub
    Public Sub playVictoria()
        Dim songLocation = Application.StartupPath & "\victoria.mp3"
        fondo.URL = songLocation
        fondo.settings.setMode("Loop", True)
        fondo.controls.play()
    End Sub
    Private Sub cargarTop()
        Dim conexion As New Conexion
        Dim offset As Integer = 0
        Dim fontsize As Single = 14.0!
        Dim arrayTop As New List(Of String)
        arrayTop = conexion.getTop()
        Dim read = Linq.JObject.Parse(arrayTop(arrayTop.Count - 1))
        If puntos > CInt(read("puntuacion")) Then
            conexion.putPuntuacion(menu.nombre, puntos, read("_id"))
        End If
        arrayTop = New List(Of String)
        arrayTop = conexion.getTop()
        For i As Integer = 1 To arrayTop.Count
            read = Linq.JObject.Parse(arrayTop(i - 1))
            Dim label As Label = New Label
            label.Size = New Size(500, 16)
            label.BackColor = lblTop.BackColor
            label.TextAlign = ContentAlignment.MiddleCenter
            label.Font = New Font("Centaur", fontsize, FontStyle.Regular, GraphicsUnit.Point)
            label.Text = i & "º.- " & read("nick").ToString & ": " & read("puntuacion").ToString + vbCrLf
            If read("nick").ToString = menu.nombre Then
                label.ForeColor = Color.White
            End If
            label.Location = New Point(Me.Width / 2 - label.Size.Width / 2, 117 + offset)
            label.BringToFront()
            Me.Controls.Add(label)
            lblTop.SendToBack()
            offset += 22
            fontsize -= 0.3!
        Next
    End Sub
    Private Sub OnClickAnywhere(sender As Object, e As EventArgs) Handles Me.Click, lblArriba.Click, lblTop.Click, lblPuntuacion.Click
        menu.Show()
        menu.playBackgroundSound()
        fondo.controls.stop()
        Me.Close()
    End Sub
    Private Sub almificar()
        lblArriba.Text = lblArriba.Text.Replace("A", "ALMI")
        lblPuntuacion.Text = lblPuntuacion.Text.Replace("a", "almi")
    End Sub
End Class