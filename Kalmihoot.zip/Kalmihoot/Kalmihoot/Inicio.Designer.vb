﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class Inicio
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Inicio))
        Me.lblNick = New System.Windows.Forms.Label()
        Me.txtNick = New System.Windows.Forms.TextBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.btnSalir = New System.Windows.Forms.Button()
        Me.btnEntrar = New System.Windows.Forms.Button()
        Me.btnAlmi = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'lblNick
        '
        Me.lblNick.BackColor = System.Drawing.Color.FromArgb(CType(CType(54, Byte), Integer), CType(CType(66, Byte), Integer), CType(CType(120, Byte), Integer))
        Me.lblNick.Font = New System.Drawing.Font("Centaur", 26.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point)
        Me.lblNick.ForeColor = System.Drawing.Color.White
        Me.lblNick.Location = New System.Drawing.Point(12, 61)
        Me.lblNick.Name = "lblNick"
        Me.lblNick.Size = New System.Drawing.Size(210, 51)
        Me.lblNick.TabIndex = 0
        Me.lblNick.Text = "Elige tu nick:"
        Me.lblNick.TextAlign = System.Drawing.ContentAlignment.TopCenter
        '
        'txtNick
        '
        Me.txtNick.BackColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.txtNick.Font = New System.Drawing.Font("Centaur", 26.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point)
        Me.txtNick.ForeColor = System.Drawing.Color.Black
        Me.txtNick.Location = New System.Drawing.Point(245, 59)
        Me.txtNick.Name = "txtNick"
        Me.txtNick.Size = New System.Drawing.Size(246, 47)
        Me.txtNick.TabIndex = 1
        '
        'Label1
        '
        Me.Label1.BackColor = System.Drawing.Color.FromArgb(CType(CType(54, Byte), Integer), CType(CType(66, Byte), Integer), CType(CType(120, Byte), Integer))
        Me.Label1.Location = New System.Drawing.Point(5, 31)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(494, 98)
        Me.Label1.TabIndex = 2
        '
        'Label2
        '
        Me.Label2.BackColor = System.Drawing.Color.FromArgb(CType(CType(54, Byte), Integer), CType(CType(66, Byte), Integer), CType(CType(120, Byte), Integer))
        Me.Label2.Location = New System.Drawing.Point(-10, 21)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(528, 118)
        Me.Label2.TabIndex = 3
        '
        'btnSalir
        '
        Me.btnSalir.BackColor = System.Drawing.Color.FromArgb(CType(CType(54, Byte), Integer), CType(CType(66, Byte), Integer), CType(CType(120, Byte), Integer))
        Me.btnSalir.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.btnSalir.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnSalir.FlatAppearance.BorderColor = System.Drawing.Color.White
        Me.btnSalir.FlatAppearance.BorderSize = 0
        Me.btnSalir.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnSalir.Font = New System.Drawing.Font("Centaur", 20.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point)
        Me.btnSalir.ForeColor = System.Drawing.Color.White
        Me.btnSalir.Location = New System.Drawing.Point(12, 168)
        Me.btnSalir.Name = "btnSalir"
        Me.btnSalir.Size = New System.Drawing.Size(227, 47)
        Me.btnSalir.TabIndex = 4
        Me.btnSalir.Text = "SALIR"
        Me.btnSalir.UseVisualStyleBackColor = False
        '
        'btnEntrar
        '
        Me.btnEntrar.BackColor = System.Drawing.Color.FromArgb(CType(CType(54, Byte), Integer), CType(CType(66, Byte), Integer), CType(CType(120, Byte), Integer))
        Me.btnEntrar.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.btnEntrar.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnEntrar.Enabled = False
        Me.btnEntrar.FlatAppearance.BorderColor = System.Drawing.Color.White
        Me.btnEntrar.FlatAppearance.BorderSize = 0
        Me.btnEntrar.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnEntrar.Font = New System.Drawing.Font("Centaur", 20.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point)
        Me.btnEntrar.ForeColor = System.Drawing.Color.White
        Me.btnEntrar.Location = New System.Drawing.Point(264, 168)
        Me.btnEntrar.Name = "btnEntrar"
        Me.btnEntrar.Size = New System.Drawing.Size(227, 47)
        Me.btnEntrar.TabIndex = 5
        Me.btnEntrar.Text = "ENTRAR"
        Me.btnEntrar.UseVisualStyleBackColor = False
        '
        'btnAlmi
        '
        Me.btnAlmi.BackColor = System.Drawing.Color.Transparent
        Me.btnAlmi.BackgroundImage = Global.Kalmihoot.My.Resources.Resources.almi
        Me.btnAlmi.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom
        Me.btnAlmi.FlatAppearance.BorderSize = 0
        Me.btnAlmi.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnAlmi.Location = New System.Drawing.Point(216, 221)
        Me.btnAlmi.Name = "btnAlmi"
        Me.btnAlmi.Size = New System.Drawing.Size(69, 47)
        Me.btnAlmi.TabIndex = 6
        Me.btnAlmi.UseVisualStyleBackColor = False
        '
        'Inicio
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(7.0!, 15.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.FromArgb(CType(CType(6, Byte), Integer), CType(CType(170, Byte), Integer), CType(CType(219, Byte), Integer))
        Me.ClientSize = New System.Drawing.Size(503, 272)
        Me.ControlBox = False
        Me.Controls.Add(Me.btnAlmi)
        Me.Controls.Add(Me.btnEntrar)
        Me.Controls.Add(Me.btnSalir)
        Me.Controls.Add(Me.txtNick)
        Me.Controls.Add(Me.lblNick)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.Label2)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "Inicio"
        Me.SizeGripStyle = System.Windows.Forms.SizeGripStyle.Show
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Kalmihoot"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents Label1 As Label
    Friend WithEvents lblNick As Label
    Friend WithEvents txtNick As TextBox
    Friend WithEvents Label2 As Label
    Friend WithEvents btnSalir As Button
    Friend WithEvents btnEntrar As Button
    Friend WithEvents btnAlmi As Button
End Class
