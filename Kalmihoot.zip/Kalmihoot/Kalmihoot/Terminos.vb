﻿Public Class Terminos
    Public ini As Inicio
    Private Sub btnCerrar_Click(sender As Object, e As EventArgs) Handles btnCerrar.Click
        ini.Close()
        Close()
    End Sub
    Private Sub btnAceptar_Click(sender As Object, e As EventArgs) Handles btnAceptar.Click
        ini.Enabled = True
        Me.Close()
    End Sub
End Class