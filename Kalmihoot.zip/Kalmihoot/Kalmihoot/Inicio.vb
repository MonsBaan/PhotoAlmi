﻿Imports WMPLib

Public Class Inicio
    Public almi As Boolean = False

    Private Sub Inicio_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Dim ter As Terminos = New Terminos
        ter.ini = Me
        Me.Enabled = False
        ter.Show()
        ter.TopMost = True
    End Sub
    Private Sub btnSalir_Click(sender As Object, e As EventArgs) Handles btnSalir.Click
        playBoton()
        Close()
    End Sub
    Private Sub btnEntrar_Click(sender As Object, e As EventArgs) Handles btnEntrar.Click
        Dim menu As Menu = New Menu()
        menu.inicio = Me
        menu.nombre = txtNick.Text
        Me.Hide()
        menu.Show()
        playBoton()
    End Sub
    Private Sub txtNick_TextChanged(sender As Object, e As EventArgs) Handles txtNick.TextChanged
        If txtNick.Text.Length > 0 And txtNick.Text.Length < 10 Then
            btnEntrar.Enabled = True
        Else
            btnEntrar.Enabled = False
        End If
        playText()
    End Sub
    Private Sub btnAlmi_Click(sender As Object, e As EventArgs) Handles btnAlmi.Click
        almi = Not almi
        almificar(almi)
        playBoton()
    End Sub
    Private Sub playBoton()
        Dim boton As WindowsMediaPlayer = New WindowsMediaPlayer
        Dim songLocation = Application.StartupPath & "\boton.mp3"
        boton.URL = songLocation
        boton.controls.currentPosition = 0.3
        boton.controls.play()
    End Sub
    Private Sub playText()
        Dim text As WindowsMediaPlayer = New WindowsMediaPlayer
        Dim songLocation = Application.StartupPath & "\tick.mp3"
        text.URL = songLocation
        text.controls.currentPosition = 0.1
        text.controls.play()
    End Sub
    Private Sub almificar(sino As Boolean)
        If sino Then
            btnSalir.Text = btnSalir.Text.Replace("a", "almi")
            btnSalir.Text = btnSalir.Text.Replace("A", "ALMI")
            btnEntrar.Text = btnEntrar.Text.Replace("a", "almi")
            btnEntrar.Text = btnEntrar.Text.Replace("A", "ALMI")
        Else
            btnSalir.Text = btnSalir.Text.Replace("almi", "a")
            btnSalir.Text = btnSalir.Text.Replace("ALMI", "A")
            btnEntrar.Text = btnEntrar.Text.Replace("almi", "a")
            btnEntrar.Text = btnEntrar.Text.Replace("ALMI", "A")
        End If
    End Sub
End Class
