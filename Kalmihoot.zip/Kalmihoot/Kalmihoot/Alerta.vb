﻿Imports WMPLib

Public Class Alerta
    Public preguntas As Preguntas
    Public texto As String
    Public boton As String
    Private Sub Alerta_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        preguntas.Enabled = False
        lblTexto.Text = texto
        Button1.Text = boton
    End Sub
    Public Sub playError()
        Dim boton As WindowsMediaPlayer = New WindowsMediaPlayer
        Dim songLocation = Application.StartupPath & "\error.mp3"
        boton.URL = songLocation
        boton.controls.currentPosition = 2
        boton.controls.play()
    End Sub
    Public Sub playAcierto()
        Dim boton As WindowsMediaPlayer = New WindowsMediaPlayer
        Dim songLocation = Application.StartupPath & "\yay.mp3"
        boton.URL = songLocation
        boton.controls.play()
    End Sub
    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        preguntas.Enabled = True
        preguntas.resetear()
        Me.Close()
    End Sub
End Class