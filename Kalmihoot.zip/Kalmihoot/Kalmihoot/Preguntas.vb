﻿Imports Newtonsoft.Json
Imports WMPLib
Public Class Preguntas
    Public menu As Menu
    Private puntos As Integer
    Private explicacion As String
    Private vidas As Integer
    Private rondas As Integer
    Private tiempoImagen As Integer = 5
    Private tiempoPregunta As Integer
    Private preguntas As List(Of String)
    Private correcta As String
    Private cerrado As Boolean = False
    Private aciertos, idCat, idPreg As String
    Private fondo As WindowsMediaPlayer = New WindowsMediaPlayer
    Dim conexion As Conexion = New Conexion
    Private Sub Preguntas_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        vidas = menu.vidas
        rondas = menu.preguntas
        puntos = 0
        preguntas = New List(Of String)
        preguntas = conexion.getPreguntas(menu.categoria)
        idCat = conexion.getIdCategoria(menu.categoria)
        resetear()
        playBackgroundSound()
    End Sub
    Private Sub playBackgroundSound()
        Dim songLocation = Application.StartupPath & "\fondoJuego.mp3"
        fondo.URL = songLocation
        fondo.settings.setMode("Loop", True)
        fondo.controls.play()
    End Sub
    Public Sub sumarPuntos()
        puntos += 1000 * (tiempoPregunta / menu.tiempo) * menu.puntos
    End Sub
    Private Sub btnSalir_Click(sender As Object, e As EventArgs) Handles btnSalir.Click
        cerrar(False)
    End Sub
    Private Sub btnPausa_Click(sender As Object, e As EventArgs) Handles btnPausa.Click
        lblPause.Show()
        timerPregunta.Stop()
        activarBotones(False)
    End Sub
    Private Sub btnA_Click(sender As Object, e As EventArgs) Handles btnA.Click
        If correcta.IndexOf("A") > -1 Then
            mensaje(True)
        Else
            mensaje(False)
        End If
    End Sub

    Private Sub btnB_Click(sender As Object, e As EventArgs) Handles btnB.Click
        If correcta.IndexOf("B") > -1 Then
            mensaje(True)
        Else
            mensaje(False)
        End If
    End Sub

    Private Sub btnC_Click(sender As Object, e As EventArgs) Handles btnC.Click
        If correcta.IndexOf("C") > -1 Then
            mensaje(True)
        Else
            mensaje(False)
        End If
    End Sub

    Private Sub btnD_Click(sender As Object, e As EventArgs) Handles btnD.Click
        If correcta.IndexOf("D") > -1 Then
            mensaje(True)
        Else
            mensaje(False)
        End If
    End Sub
    Private Sub mensaje(acierto As Boolean)
        timerPregunta.Stop()
        Dim alerta As Alerta = New Alerta()
        alerta.preguntas = Me
        If acierto Then
            If menu.almi Then
                alerta.Text = "Almicertalmiste"
                alerta.boton = "Continualmir"
            Else
                alerta.Text = "Acertaste"
                alerta.boton = "Continuar"
            End If
            conexion.putAciertos(idCat, idPreg, aciertos + 1)
            alerta.BackColor = Color.LightGreen
            alerta.texto = "Correcto."
            alerta.playAcierto()
            sumarPuntos()
        Else
            vidas -= 1
            alerta.BackColor = Color.LightPink
            If menu.almi Then
                alerta.Text = "Falmillalmiste"
                alerta.texto = explicacion.Replace("a", "almi")
                alerta.texto = alerta.texto.Replace("A", "Almi")
                alerta.boton = "Continualmir"
            Else
                alerta.Text = "Fallaste"
                alerta.boton = "Continuar"
                alerta.texto = explicacion
            End If
            conexion.putAciertos(idCat, idPreg, aciertos - 1)
            alerta.playError()
        End If
        alerta.Show()
    End Sub
    Private Sub timerPregunta_Tick(sender As Object, e As EventArgs) Handles timerPregunta.Tick
        If cerrado Then
            Return
        End If
        tiempoPregunta -= 1
        btnTimer.Text = tiempoPregunta
        If tiempoPregunta <= 0 Then
            timerPregunta.Stop()
            mensaje(False)
        End If
    End Sub
    Private Sub timerImagen_Tick(sender As Timer, e As EventArgs) Handles timerImagen.Tick
        tiempoImagen -= 1
        If tiempoImagen <= 0 Then
            btnPausa.Enabled = True
            activarBotones(True)
            lblImagen.Hide()
            timerImagen.Stop()
            timerPregunta.Start()
            btnTimer.Text = tiempoPregunta
        End If
    End Sub
    Public Sub activarBotones(sino As Boolean)
        btnA.Enabled = sino
        btnB.Enabled = sino
        btnC.Enabled = sino
        btnD.Enabled = sino
        btnSalir.Enabled = sino
    End Sub
    Public Sub resetear()
        If cerrado Then
            Return
        End If
        If vidas = 0 Then
            cerrar(False)
            Return
        End If
        If rondas <= 0 Then
            cerrar(True)
            Return
        End If
        rondas -= 1
        activarBotones(False)
        cargarPregunta()
        tiempoImagen = 5
        tiempoPregunta = menu.tiempo
        btnVidas.Text = vidas
        lblImagen.Show()
        timerImagen.Start()
    End Sub
    Public Sub cerrar(ganar As Boolean)
        cerrado = True
        fondo.controls.stop()
        Dim top As Top = New Top
        top.menu = menu
        top.puntos = puntos
        top.ganar = ganar
        top.Show()
        timerImagen.Stop()
        timerImagen.Enabled = False
        timerPregunta.Stop()
        timerPregunta.Enabled = False
        Me.Enabled = False
        Me.Close()
    End Sub
    Private Function _
        GetImageFromURL(ByVal url As String) As Image

        Dim retVal As Image = Nothing

        Try
            If Not String.IsNullOrWhiteSpace(url) Then
                Dim req As System.Net.WebRequest = System.Net.WebRequest.Create(url.Trim)

                Using request As System.Net.WebResponse = req.GetResponse
                    Using stream As System.IO.Stream = request.GetResponseStream
                        retVal = New Bitmap(System.Drawing.Image.FromStream(stream))
                    End Using
                End Using
            End If

        Catch ex As Exception
            retVal = Global.Kalmihoot.My.Resources.Resources._ERROR
        End Try

        Return retVal

    End Function
    Private Sub cargarPregunta()
        If cerrado Then
            Return
        End If
        If preguntas.Count <= 0 Then
            cerrar(True)
            Return
        End If
        Dim rand As New Random
        Dim num As Integer = rand.Next(0, preguntas.Count - 1)
        correcta = ""
        Dim read = Linq.JObject.Parse(preguntas.Item(num))
        preguntas.RemoveAt(num)
        lblImagen.Image = New Bitmap(GetImageFromURL(read("imagen")), New Drawing.Size(lblImagen.Width / 1.5, lblImagen.Height / 1.5))
        lblPregunta.Text = read.Item("pregunta").ToString
        aciertos = read.Item("numAciertos").ToString
        idPreg = read.Item("_id").ToString
        explicacion = read.Item("correccion")
        Dim resOrdenadas As List(Of String) = New List(Of String)
        Dim res As List(Of String) = New List(Of String)
        For i As Integer = 0 To read.Item("respuestas").Count - 1
            resOrdenadas.Add(read.Item("respuestas")(i).ToString)
        Next
        While resOrdenadas.Count > 0
            num = rand.Next(0, resOrdenadas.Count - 1)
            res.Add(resOrdenadas(num))
            resOrdenadas.RemoveAt(num)
        End While
        Select Case res.Count
            Case 2
                btnA.Text = Linq.JObject.Parse(res(0)).Item("respuesta").ToString
                btnA.Size = New Size(378, 190)
                btnB.Text = Linq.JObject.Parse(res(1)).Item("respuesta").ToString
                btnB.Size = New Size(378, 190)
                btnC.Hide()
                btnD.Hide()
            Case 3
                btnA.Text = Linq.JObject.Parse(res(0)).Item("respuesta").ToString
                btnA.Size = New Size(378, 91)
                btnB.Text = Linq.JObject.Parse(res(1)).Item("respuesta").ToString
                btnB.Size = New Size(378, 91)
                btnC.Show()
                btnC.Text = Linq.JObject.Parse(res(2)).Item("respuesta").ToString
                btnC.Size = New Size(766, 91)
                btnD.Hide()
            Case 4
                btnA.Text = Linq.JObject.Parse(res(0)).Item("respuesta").ToString
                btnA.Size = New Size(378, 91)
                btnB.Text = Linq.JObject.Parse(res(1)).Item("respuesta").ToString
                btnB.Size = New Size(378, 91)
                btnC.Show()
                btnC.Text = Linq.JObject.Parse(res(2)).Item("respuesta").ToString
                btnC.Size = New Size(378, 91)
                btnD.Show()
                btnD.Text = Linq.JObject.Parse(res(3)).Item("respuesta").ToString
                btnD.Size = New Size(378, 91)
        End Select
        If Linq.JObject.Parse(res(0)).Item("correcta").ToString.Equals("True") Then
            correcta = correcta & "A"
        End If
        If Linq.JObject.Parse(res(1)).Item("correcta").ToString.Equals("True") Then
            correcta = correcta & "B"
        End If
        If res.Count > 2 Then
            If Linq.JObject.Parse(res(2)).Item("correcta").ToString.Equals("True") Then
                correcta = correcta & "C"
            End If
        End If
        If res.Count > 3 Then
            If Linq.JObject.Parse(res(3)).Item("correcta").ToString.Equals("True") Then
                correcta = correcta & "D"
            End If
        End If
        If menu.almi Then
            almificar()
        End If
    End Sub
    Private Sub lblPause_Click(sender As Object, e As EventArgs) Handles lblPause.Click
        lblPause.Hide()
        timerPregunta.Start()
        activarBotones(True)
    End Sub
    Private Sub almificar()
        lblPregunta.Text = lblPregunta.Text.Replace("a", "almi")
        lblPregunta.Text = lblPregunta.Text.Replace("A", "Almi")
        btnA.Text = btnA.Text.Replace("a", "almi")
        btnA.Text = btnA.Text.Replace("A", "Almi")
        btnB.Text = btnB.Text.Replace("a", "almi")
        btnB.Text = btnB.Text.Replace("A", "Almi")
        btnC.Text = btnC.Text.Replace("a", "almi")
        btnC.Text = btnC.Text.Replace("A", "Almi")
        btnD.Text = btnD.Text.Replace("a", "almi")
        btnD.Text = btnD.Text.Replace("A", "Almi")
        btnSalir.Text = btnSalir.Text.Replace("A", "ALMI")
    End Sub
End Class
