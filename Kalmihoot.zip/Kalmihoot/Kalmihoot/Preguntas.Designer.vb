﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class Preguntas
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Preguntas))
        Me.lblPregunta = New System.Windows.Forms.Label()
        Me.btnC = New System.Windows.Forms.Button()
        Me.btnD = New System.Windows.Forms.Button()
        Me.btnA = New System.Windows.Forms.Button()
        Me.btnB = New System.Windows.Forms.Button()
        Me.btnSalir = New System.Windows.Forms.Button()
        Me.timerImagen = New System.Windows.Forms.Timer(Me.components)
        Me.btnVidas = New System.Windows.Forms.Button()
        Me.btnTimer = New System.Windows.Forms.Button()
        Me.timerPregunta = New System.Windows.Forms.Timer(Me.components)
        Me.btnPausa = New System.Windows.Forms.Button()
        Me.lblImagen = New System.Windows.Forms.Label()
        Me.lblPause = New System.Windows.Forms.Label()
        Me.SuspendLayout()
        '
        'lblPregunta
        '
        Me.lblPregunta.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.lblPregunta.BackColor = System.Drawing.Color.FromArgb(CType(CType(54, Byte), Integer), CType(CType(66, Byte), Integer), CType(CType(120, Byte), Integer))
        Me.lblPregunta.Font = New System.Drawing.Font("Centaur", 24.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point)
        Me.lblPregunta.ForeColor = System.Drawing.Color.White
        Me.lblPregunta.Location = New System.Drawing.Point(-1, 0)
        Me.lblPregunta.Name = "lblPregunta"
        Me.lblPregunta.Size = New System.Drawing.Size(767, 117)
        Me.lblPregunta.TabIndex = 0
        Me.lblPregunta.Text = "¿Alguna vez has escuchado la tragedia de Darth Plageus el Sabio?"
        Me.lblPregunta.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'btnC
        '
        Me.btnC.BackColor = System.Drawing.Color.FromArgb(CType(CType(128, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer))
        Me.btnC.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnC.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.btnC.Font = New System.Drawing.Font("Centaur", 20.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.btnC.Location = New System.Drawing.Point(-1, 240)
        Me.btnC.Name = "btnC"
        Me.btnC.Size = New System.Drawing.Size(378, 91)
        Me.btnC.TabIndex = 1
        Me.btnC.Text = "No me gusta la arena."
        Me.btnC.UseVisualStyleBackColor = False
        '
        'btnD
        '
        Me.btnD.BackColor = System.Drawing.Color.FromArgb(CType(CType(128, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.btnD.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnD.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.btnD.Font = New System.Drawing.Font("Centaur", 20.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.btnD.Location = New System.Drawing.Point(388, 240)
        Me.btnD.Name = "btnD"
        Me.btnD.Size = New System.Drawing.Size(378, 91)
        Me.btnD.TabIndex = 2
        Me.btnD.Text = "¿Eres un Sith o me estoy liando?"
        Me.btnD.UseVisualStyleBackColor = False
        '
        'btnA
        '
        Me.btnA.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(128, Byte), Integer))
        Me.btnA.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnA.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.btnA.Font = New System.Drawing.Font("Centaur", 20.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.btnA.Location = New System.Drawing.Point(-1, 143)
        Me.btnA.Name = "btnA"
        Me.btnA.Size = New System.Drawing.Size(378, 91)
        Me.btnA.TabIndex = 3
        Me.btnA.Text = "Si"
        Me.btnA.UseVisualStyleBackColor = False
        '
        'btnB
        '
        Me.btnB.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer))
        Me.btnB.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnB.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.btnB.Font = New System.Drawing.Font("Centaur", 20.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.btnB.Location = New System.Drawing.Point(388, 143)
        Me.btnB.Name = "btnB"
        Me.btnB.Size = New System.Drawing.Size(378, 91)
        Me.btnB.TabIndex = 4
        Me.btnB.Text = "No"
        Me.btnB.UseVisualStyleBackColor = False
        '
        'btnSalir
        '
        Me.btnSalir.BackColor = System.Drawing.Color.White
        Me.btnSalir.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnSalir.Font = New System.Drawing.Font("Centaur", 14.25!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point)
        Me.btnSalir.Location = New System.Drawing.Point(331, 340)
        Me.btnSalir.Name = "btnSalir"
        Me.btnSalir.Size = New System.Drawing.Size(101, 40)
        Me.btnSalir.TabIndex = 5
        Me.btnSalir.Text = "SALIR"
        Me.btnSalir.UseVisualStyleBackColor = False
        '
        'timerImagen
        '
        Me.timerImagen.Enabled = True
        Me.timerImagen.Interval = 1000
        '
        'btnVidas
        '
        Me.btnVidas.BackColor = System.Drawing.Color.Transparent
        Me.btnVidas.BackgroundImage = Global.Kalmihoot.My.Resources.Resources.Corazón1
        Me.btnVidas.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.btnVidas.Enabled = False
        Me.btnVidas.FlatAppearance.BorderSize = 0
        Me.btnVidas.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnVidas.Font = New System.Drawing.Font("Centaur", 21.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point)
        Me.btnVidas.ForeColor = System.Drawing.Color.Black
        Me.btnVidas.Location = New System.Drawing.Point(12, 340)
        Me.btnVidas.Name = "btnVidas"
        Me.btnVidas.Size = New System.Drawing.Size(47, 40)
        Me.btnVidas.TabIndex = 6
        Me.btnVidas.Text = "3"
        Me.btnVidas.UseVisualStyleBackColor = False
        '
        'btnTimer
        '
        Me.btnTimer.BackgroundImage = Global.Kalmihoot.My.Resources.Resources.orange_circle_background
        Me.btnTimer.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.btnTimer.Enabled = False
        Me.btnTimer.FlatAppearance.BorderSize = 0
        Me.btnTimer.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnTimer.Font = New System.Drawing.Font("Centaur", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point)
        Me.btnTimer.Location = New System.Drawing.Point(708, 341)
        Me.btnTimer.Name = "btnTimer"
        Me.btnTimer.Size = New System.Drawing.Size(45, 40)
        Me.btnTimer.TabIndex = 7
        Me.btnTimer.Text = "00"
        Me.btnTimer.UseVisualStyleBackColor = True
        '
        'timerPregunta
        '
        Me.timerPregunta.Interval = 1000
        '
        'btnPausa
        '
        Me.btnPausa.BackColor = System.Drawing.Color.Silver
        Me.btnPausa.BackgroundImage = Global.Kalmihoot.My.Resources.Resources._1200px_OOjs_UI_icon_pause_svg
        Me.btnPausa.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.btnPausa.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnPausa.Enabled = False
        Me.btnPausa.FlatAppearance.BorderSize = 0
        Me.btnPausa.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnPausa.Location = New System.Drawing.Point(115, 343)
        Me.btnPausa.Name = "btnPausa"
        Me.btnPausa.Size = New System.Drawing.Size(45, 40)
        Me.btnPausa.TabIndex = 8
        Me.btnPausa.UseVisualStyleBackColor = False
        '
        'lblImagen
        '
        Me.lblImagen.Image = Global.Kalmihoot.My.Resources.Resources._ERROR
        Me.lblImagen.Location = New System.Drawing.Point(-1, -1)
        Me.lblImagen.Name = "lblImagen"
        Me.lblImagen.Size = New System.Drawing.Size(766, 390)
        Me.lblImagen.TabIndex = 16
        '
        'lblPause
        '
        Me.lblPause.BackColor = System.Drawing.Color.SteelBlue
        Me.lblPause.Cursor = System.Windows.Forms.Cursors.Hand
        Me.lblPause.Image = Global.Kalmihoot.My.Resources.Resources.play
        Me.lblPause.Location = New System.Drawing.Point(-1, -1)
        Me.lblPause.Name = "lblPause"
        Me.lblPause.Size = New System.Drawing.Size(766, 390)
        Me.lblPause.TabIndex = 18
        Me.lblPause.Visible = False
        '
        'Preguntas
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(7.0!, 15.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.FromArgb(CType(CType(6, Byte), Integer), CType(CType(170, Byte), Integer), CType(CType(219, Byte), Integer))
        Me.ClientSize = New System.Drawing.Size(765, 389)
        Me.ControlBox = False
        Me.Controls.Add(Me.lblPause)
        Me.Controls.Add(Me.lblImagen)
        Me.Controls.Add(Me.btnPausa)
        Me.Controls.Add(Me.btnTimer)
        Me.Controls.Add(Me.btnVidas)
        Me.Controls.Add(Me.btnSalir)
        Me.Controls.Add(Me.btnB)
        Me.Controls.Add(Me.btnA)
        Me.Controls.Add(Me.btnD)
        Me.Controls.Add(Me.btnC)
        Me.Controls.Add(Me.lblPregunta)
        Me.DoubleBuffered = True
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.Name = "Preguntas"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Kalmihoot"
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents lblPregunta As Label
    Friend WithEvents btnC As Button
    Friend WithEvents btnD As Button
    Friend WithEvents btnA As Button
    Friend WithEvents btnB As Button
    Friend WithEvents btnSalir As Button
    Friend WithEvents timerImagen As Timer
    Friend WithEvents btnVidas As Button
    Friend WithEvents btnTimer As Button
    Friend WithEvents timerPregunta As Timer
    Friend WithEvents btnPausa As Button
    Friend WithEvents lblImagen As Label
    Friend WithEvents lblPause As Label
End Class
