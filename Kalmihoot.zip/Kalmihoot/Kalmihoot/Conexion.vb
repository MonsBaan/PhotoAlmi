﻿Imports System.Net
Imports Newtonsoft.Json
Imports System.Text
Public Class Conexion
    Dim n As WebClient = New WebClient()

    Public Function getTop() As List(Of String)
        Dim json = n.DownloadString("http://192.168.6.195:8080/kalmihootapi/top10")
        Dim read = Linq.JObject.Parse(json)
        Dim arrayTop As New List(Of String)
        For i As Integer = 0 To read.Item("data").Count - 1
            arrayTop.Add(read.Item("data")(i).ToString)
        Next
        Return arrayTop
    End Function
    Public Function getPreguntas(cat As String) As List(Of String)
        Dim json = n.DownloadString("http://192.168.6.195:8080/kalmihootapi/preguntas/" & cat)
        Dim read = Linq.JObject.Parse(json)
        Dim arrayPreg As New List(Of String)
        For i As Integer = 0 To read.Item("data")("preguntas").Count - 1
            arrayPreg.Add(read.Item("data")("preguntas")(i).ToString)
        Next
        Return arrayPreg
    End Function
    Public Function getIdCategoria(cat As String) As String
        Dim json = n.DownloadString("http://192.168.6.195:8080/kalmihootapi/preguntas/" & cat)
        Dim read = Linq.JObject.Parse(json)
        Return read.Item("data")("_id")
    End Function
    Public Function getCategorias() As List(Of String)
        Dim json = n.DownloadString("http://192.168.6.195:8080/kalmihootapi/categorias")
        Dim read = Linq.JObject.Parse(json)
        Dim arrayCat As List(Of String) = New List(Of String)
        For i As Integer = 0 To read.Item("data").Count - 1
            Dim str As String = read.Item("data")(i).ToString
            arrayCat.Add(str)
        Next
        Return arrayCat
    End Function
    Public Sub putPuntuacion(nick As String, puntos As Integer, reemplazar As String)
        n.Headers("content-type") = "application/json"
        Dim obj As New Dictionary(Of String, Object)
        obj.Add("nick", nick)
        obj.Add("puntuacion", puntos)
        Dim str As String = JsonConvert.SerializeObject(obj, Formatting.None)
        Dim req() As Byte = Encoding.Default.GetBytes(str)
        Dim resByte As Byte() = n.UploadData("http://192.168.6.195:8080/kalmihootapi/puntuacion/" & reemplazar, "put", req)
    End Sub
    Public Sub putAciertos(idCat As String, idPreg As String, aciertos As String)
        n.Headers("content-type") = "application/json"
        Dim req() As Byte = Encoding.Default.GetBytes("")
        Dim resByte As Byte() = n.UploadData("http://192.168.6.195:8080/kalmihootApi/numAciertos/" & idCat & "/" & idPreg & "/" & aciertos, "put", req)
    End Sub
End Class
