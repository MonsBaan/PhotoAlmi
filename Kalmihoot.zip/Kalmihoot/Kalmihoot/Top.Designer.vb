﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class Top
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Top))
        Me.lblArriba = New System.Windows.Forms.Label()
        Me.lblTop = New System.Windows.Forms.Label()
        Me.lblPuntuacion = New System.Windows.Forms.Label()
        Me.SuspendLayout()
        '
        'lblArriba
        '
        Me.lblArriba.BackColor = System.Drawing.Color.DarkCyan
        Me.lblArriba.Font = New System.Drawing.Font("Centaur", 48.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point)
        Me.lblArriba.ForeColor = System.Drawing.Color.White
        Me.lblArriba.Location = New System.Drawing.Point(0, 0)
        Me.lblArriba.Name = "lblArriba"
        Me.lblArriba.Size = New System.Drawing.Size(801, 96)
        Me.lblArriba.TabIndex = 0
        Me.lblArriba.Text = "VICTORIA"
        Me.lblArriba.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lblTop
        '
        Me.lblTop.BackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.lblTop.Font = New System.Drawing.Font("Centaur", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point)
        Me.lblTop.Location = New System.Drawing.Point(-1, 115)
        Me.lblTop.Name = "lblTop"
        Me.lblTop.Size = New System.Drawing.Size(801, 219)
        Me.lblTop.TabIndex = 1
        Me.lblTop.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lblPuntuacion
        '
        Me.lblPuntuacion.BackColor = System.Drawing.Color.DarkCyan
        Me.lblPuntuacion.Font = New System.Drawing.Font("Centaur", 48.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point)
        Me.lblPuntuacion.ForeColor = System.Drawing.Color.White
        Me.lblPuntuacion.Location = New System.Drawing.Point(0, 354)
        Me.lblPuntuacion.Name = "lblPuntuacion"
        Me.lblPuntuacion.Size = New System.Drawing.Size(801, 96)
        Me.lblPuntuacion.TabIndex = 2
        Me.lblPuntuacion.Text = "Puntuación: 0000"
        Me.lblPuntuacion.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Top
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(7.0!, 15.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.PaleGreen
        Me.ClientSize = New System.Drawing.Size(800, 450)
        Me.ControlBox = False
        Me.Controls.Add(Me.lblTop)
        Me.Controls.Add(Me.lblArriba)
        Me.Controls.Add(Me.lblPuntuacion)
        Me.Cursor = System.Windows.Forms.Cursors.Hand
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.Name = "Top"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Top"
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents lblArriba As Label
    Friend WithEvents lblTop As Label
    Friend WithEvents lblPuntuacion As Label
End Class
