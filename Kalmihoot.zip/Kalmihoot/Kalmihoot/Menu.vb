﻿Imports WMPLib

Public Class Menu
    Public inicio As Inicio
    Public almi As Boolean
    Public nombre As String
    Public tiempo As Integer
    Public vidas As Integer
    Public preguntas As Integer
    Public puntos As Double
    Public categoria As String
    Private fondo As WindowsMediaPlayer = New WindowsMediaPlayer
    Private Sub Menu_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        lblNick.Text = nombre
        almi = inicio.almi
        If almi Then
            almificar()
        End If
        cargarCats()
        playBackgroundSound()
    End Sub
    Public Sub playBackgroundSound()
        Dim songLocation = Application.StartupPath & "\fondoMenu.mp3"
        fondo.URL = songLocation
        fondo.settings.setMode("Loop", True)
        fondo.controls.play()
    End Sub
    Private Sub playBoton()
        Dim boton As WindowsMediaPlayer = New WindowsMediaPlayer
        Dim songLocation = Application.StartupPath & "\boton.mp3"
        boton.URL = songLocation
        boton.controls.currentPosition = 0.3
        boton.controls.play()
    End Sub
    Private Sub cargarCats()
        Dim conexion As Conexion = New Conexion
        Dim cats As List(Of String) = New List(Of String)
        cats = conexion.getCategorias()
        comboCat.Items.Clear()
        For i As Integer = 0 To cats.Count - 1
            comboCat.Items.Add(cats(i))
        Next
    End Sub
    Private Sub btnCerrar_Click(sender As Object, e As EventArgs) Handles btnCerrar.Click
        inicio.Show()
        playBoton()
        fondo.controls.stop()
        Me.Close()
    End Sub
    Private Sub comboCat_SelectedIndexChanged(sender As Object, e As EventArgs) Handles comboCat.SelectedIndexChanged
        If lblCategoria.Visible = True Then
            lblCategoria.Hide()
        End If
        categoria = comboCat.SelectedItem.ToString
        playBoton()
    End Sub
    Private Sub comboNivel_SelectedIndexChanged(sender As ComboBox, e As EventArgs) Handles comboNivel.SelectedIndexChanged
        If lblDificultad.Visible = True Then
            lblDificultad.Hide()
        End If
        playBoton()
        Select Case sender.SelectedItem.ToString()
            Case "Facil"
                tiempo = 30
                vidas = 3
                preguntas = 5
                puntos = 0.5
            Case "Media"
                tiempo = 20
                vidas = 3
                preguntas = 8
                puntos = 1
            Case "Difícil"
                tiempo = 15
                vidas = 1
                preguntas = 10
                puntos = 2
        End Select
        asignarValores()
    End Sub
    Private Sub btnJugar_Click(sender As Object, e As EventArgs) Handles btnJugar.Click
        If comboNivel.SelectedIndex >= 0 And comboCat.SelectedIndex >= 0 Then
            Dim preguntas As Preguntas = New Preguntas()
            preguntas.menu = Me
            preguntas.Show()
            fondo.controls.stop()
            Me.Hide()
        End If
        playBoton()
    End Sub
    Private Sub asignarValores()
        lblTiempo.Text = tiempo
        lblVidas.Text = vidas
        lblPreguntas.Text = preguntas
        lblPuntos.Text = "x" & puntos
    End Sub
    Private Sub almificar()
        btnCerrar.Text = btnCerrar.Text.Replace("a", "almi")
        lblCategoria.Text = lblCategoria.Text.Replace("a", "almi")
        lblDificultad.Text = lblDificultad.Text.Replace("a", "almi")
        Label3.Text = Label3.Text.Replace("a", "almi")
        Label4.Text = Label4.Text.Replace("a", "almi")
        btnJugar.Text = btnJugar.Text.Replace("A", "ALMI")
    End Sub
End Class